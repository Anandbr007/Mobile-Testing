package POM;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class pomAPIDEMO {
	
	public AndroidDriver driver;
	
	public pomAPIDEMO(AndroidDriver driver) {
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(accessibility = "Views")
    WebElement view;
	@AndroidFindBy(accessibility = "Gallery")
    WebElement gallery;
	@AndroidFindBy(accessibility = "1. Photos")
    WebElement photos;
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.Gallery/android.widget.ImageView[1]")
    WebElement firstimg;
	
	public void gallery() {
		view.click();
		gallery.click();
		photos.click();
		
	}
	
	public void swipe(String dir,double scroll) {
		((JavascriptExecutor) driver).executeScript("mobile:swipeGesture", ImmutableMap.of(
				"elementId",((RemoteWebElement) firstimg).getId(),"direction",dir,"percent",scroll));
	}
}
