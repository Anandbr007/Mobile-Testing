package POM;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class pomDragnDrop {

	public AndroidDriver driver;
	
	public pomDragnDrop(AndroidDriver driver)
    {
        this.driver = driver;
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }
	
	@AndroidFindBy(accessibility ="Drag and Drop")
	WebElement dragndrop;
	@AndroidFindBy(id ="io.appium.android.apis:id/drag_dot_3")
	WebElement dot3;
	
	public void dragdrop()
	{
		dragndrop.click();
		((JavascriptExecutor)driver).executeScript("mobile: dragGesture", ImmutableMap.of(
				"elementId",((RemoteWebElement)dot3).getId(),"endX",618,"endY",618));
	}
}
