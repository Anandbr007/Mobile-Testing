package example;

import org.testng.annotations.Test;

import POM.pomAPIDEMO;

public class msgTest extends Basetest_APIdemos {
	pomAPIDEMO pom;
	
	@Test
	public void test() {
		pom=new pomAPIDEMO(driver);
		pom.gallery();
		pom.swipe("left",0.75);
		pom.swipe("right",0.75);
	}
	
}
