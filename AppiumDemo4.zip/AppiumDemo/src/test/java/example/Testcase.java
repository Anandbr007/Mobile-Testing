package example;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class Testcase extends BaseTest {

	
//	@Test
//	public void test() {
//		driver.findElement(AppiumBy.accessibilityId("Preference")).click();
//		driver.findElement(AppiumBy.accessibilityId("3. Preference dependencies")).click();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		driver.findElement(AppiumBy.id("android:id/checkbox")).click();
//		driver.findElement(AppiumBy.xpath("/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.ListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout")).click();
//		driver.findElement(AppiumBy.id("android:id/edit")).sendKeys("roshan");
//		driver.findElement(AppiumBy.id("android:id/button1")).click();
//		
//	}

		// This method clicks on the "Preference" option
		@Test(priority = 0)
		public void clickPreferenceOption() {
			driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Preference\"]")).click();
		}
		// This method clicks on the "3. Preference dependencies" option
		@Test(priority = 1)
		public void clickPreferenceDependenciesOption() {
			driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"3. Preference dependencies\"]"))
					.click();
		}
		// This method clicks the checkbox
		@Test(priority = 2)
		public void clickWifiCheckBox() {
			driver.findElement(AppiumBy.xpath(
					"/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.CheckBox"))
					.click();
		}
		// This method clicks on the "WiFi Settings" option
		@Test(priority = 3)
		public void clickWifiSettingsOption() {
			driver.findElement(AppiumBy.xpath(
					"/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.ListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout/android.widget.TextView"))
					.click();
		}
		// This method enters the WiFi name
		@Test(priority = 4)
		public void enterWifiName() {
			driver.findElement(AppiumBy.xpath(
					"/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.EditText"))
					.sendKeys("shebin");
		}
		// This method clicks the OK button
		@Test(priority = 5)
		public void clickOkButton() {
			driver.findElement(AppiumBy.xpath(
					"/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.Button[2]"))
					.click();
		}
	}


