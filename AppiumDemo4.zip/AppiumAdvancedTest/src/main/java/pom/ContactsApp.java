package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunctions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ContactsApp extends ReusableFunctions {

	AndroidDriver driver;
	
	@AndroidFindBy(id = "com.android.contacts:id/add_account_button")
	public WebElement addaccount;
	
	@AndroidFindBy(xpath = "//*[@text=\"Couldn't sign in\"]")
	public WebElement cannotSigninTitle;
	
	@AndroidFindBy(id = "android:id/button2")
	public WebElement skip;
	
	@AndroidFindBy(id = "com.android.contacts:id/import_contacts_button")
	public WebElement importcontacts;
	
	@AndroidFindBy(xpath = "(//android.widget.TextView)[1]")
	public WebElement contactTitle;
	
	@AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[1]/android.widget.TextView")
	public WebElement vcf_file;
	
	@AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_button")
	public WebElement allow;
	
	@AndroidFindBy(id ="com.android.documentsui:id/message")
	public WebElement noitems;
	
	@AndroidFindBy(accessibility = "Create new contact")
	public WebElement create;
	
	@AndroidFindBy(id = "com.android.contacts:id/left_button")
	public WebElement cancelbutton;
	
	@AndroidFindBy(id = "com.android.contacts:id/right_button")
	public WebElement addbutton;
	
	@AndroidFindBy(xpath = "(//android.widget.LinearLayout/android.widget.LinearLayout/android.widget.EditText[1])[1]")
	public WebElement firstname;
	
	@AndroidFindBy(xpath = "(//android.widget.LinearLayout/android.widget.LinearLayout/android.widget.EditText[2])[1]")
    public WebElement lastname;
	
	@AndroidFindBy(xpath = "(//android.widget.EditText)[3]")
	public WebElement phone;
	
	@AndroidFindBy(xpath = "//android.widget.Spinner[@content-desc=\"Phone\"]")
	public WebElement phonetypedrop;
	
	@AndroidFindBy(xpath = "//android.widget.CheckedTextView[@text =\"Mobile\"]")
	public WebElement mobiletype;
	
	@AndroidFindBy(xpath = "(//android.widget.LinearLayout/android.widget.EditText)[4]")
    public WebElement email;
	
	@AndroidFindBy(xpath = "//android.widget.Spinner[@content-desc=\"Email\"]")
	public WebElement emailtypedrop;
	
	@AndroidFindBy(xpath = "//android.widget.CheckedTextView[@text =\"Home\"]")
    public WebElement hometype;
	
	@AndroidFindBy(id = "com.android.contacts:id/editor_menu_save_button")
	public WebElement savebutton;
	
	public ContactsApp(AndroidDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
		this.driver = driver;
		
	}
	public void skip() {
		clickElement(skip);
	}
	public void clickAddAccount() {
		clickElement(addaccount);
	}
	public String canCreateAccount() {
		waits(2);
		setExplicitWait(cannotSigninTitle);
		return cannotSigninTitle.getText();
	}
	public boolean checkContacts() {
		waits(5);
		try {
			contactTitle.isDisplayed();
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	public void clickImportContact() {
		clickElement(importcontacts);
	}
	
	public boolean checkVcf_File() {
		waits(5);
		try {
			vcf_file.isDisplayed();
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	
	public void clickVcf_File() {
		clickElement(vcf_file);
	}
	
	public boolean checkallow() {
		waits(5);
		try {
			allow.isDisplayed();
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	
	
	public void clickAllow() {
		clickElement(allow);
	}
	
	public String noItemsPresent() {
		waits(5);
		return noitems.getText();
	}
	
	public void clickCreate() {
		clickElement(create);
	}
	
	public boolean checkaddbutton() {
		waits(5);
		try {
			addbutton.isDisplayed();
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	
	public void clickAddbutton() {
		clickElement(addbutton);
	}
	
	public void clickCancelbutton() {
        clickElement(cancelbutton);
    }
	public void goback() {
		driver.pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	}
	
	public void enterfirstname(String text) {
		sendText(firstname, text);
	}
	
	public void enterlastname(String text) {
		sendText(lastname, text);
	}
	
	public void enterphone(String text) {
        sendText(phone, text);
    }
	
	public void  clickphone() {
		clickElement(phonetypedrop);
		clickElement(mobiletype);
	}
	
	public void enteremail(String text) {
        sendText(email, text);
    }
	public void clickemail() {
		clickElement(emailtypedrop);
        clickElement(hometype);
	}
	
	public void clickSave() {
		clickElement(savebutton);
	}
	public AndroidDriver passDriver() {
		return driver;
		
	}
}
