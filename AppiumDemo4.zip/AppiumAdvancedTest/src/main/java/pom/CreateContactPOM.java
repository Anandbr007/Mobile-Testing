package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunctions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class CreateContactPOM extends ReusableFunctions{

	AndroidDriver driver;
	
	public CreateContactPOM(AndroidDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
		this.driver = driver;
		
	}
	
	
	@AndroidFindBy(id = "android:id/button2")
	public WebElement skip;
	
	@AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_button")
	public WebElement allow;

	@AndroidFindBy(xpath = "(//android.widget.TextView)[1]")
	public WebElement contactTitle;
	
	@AndroidFindBy(accessibility = "Create new contact")
	public WebElement create;
	
	@AndroidFindBy(id = "com.android.contacts:id/right_button")
	public WebElement addbutton;
	
	@AndroidFindBy(xpath = "//*[@text=\"Couldn't sign in\"]")
	public WebElement cannotSigninTitle;
	
	@AndroidFindBy(id = "com.android.contacts:id/left_button")
	public WebElement cancelbutton;
	
	@AndroidFindBy(xpath = "(//android.widget.LinearLayout/android.widget.LinearLayout/android.widget.EditText[1])[1]")
	public WebElement firstname;
	
	@AndroidFindBy(xpath = "(//android.widget.LinearLayout/android.widget.LinearLayout/android.widget.EditText[2])[1]")
    public WebElement lastname;
	
	@AndroidFindBy(xpath = "(//android.widget.EditText)[3]")
	public WebElement phone;
	
	@AndroidFindBy(xpath = "//android.widget.Spinner[@content-desc=\"Phone\"]")
	public WebElement phonetypedrop;
	
	@AndroidFindBy(xpath = "//android.widget.CheckedTextView[@text =\"Mobile\"]")
	public WebElement mobiletype;
	
	@AndroidFindBy(xpath = "(//android.widget.LinearLayout/android.widget.EditText)[4]")
    public WebElement email;
	@AndroidFindBy(xpath = "//android.widget.Spinner[@content-desc=\"Email\"]")
	public WebElement emailtypedrop;
	
	@AndroidFindBy(xpath = "//android.widget.CheckedTextView[@text =\"Home\"]")
    public WebElement hometype;
	@AndroidFindBy(id = "com.android.contacts:id/editor_menu_save_button")
	public WebElement savebutton;
	public boolean checkContacts() {
		waits(5);
		try {
			contactTitle.isDisplayed();
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	
	public void skip() {
		clickElement(skip);
	}
	
	public void clickAllow() {
		clickElement(allow);
	}
	public boolean checkallow() {
		waits(5);
		try {
			allow.isDisplayed();
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	public void clickCreate() {
		clickElement(create);
	}
	public boolean checkaddbutton() {
		waits(5);
		try {
			addbutton.isDisplayed();
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	public void clickAddbutton() {
		clickElement(addbutton);
	}
	public String canCreateAccount() {
		waits(2);
		setExplicitWait(cannotSigninTitle);
		return cannotSigninTitle.getText();
	}
	public void goback() {
		driver.pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	}
	public void clickCancelbutton() {
        clickElement(cancelbutton);
    }
	public void enterfirstname(String text) {
		sendText(firstname, text);
	}
	
	public void enterlastname(String text) {
		sendText(lastname, text);
	}
	
	public void enterphone(String text) {
        sendText(phone, text);
    }
	
	public void  clickphone() {
		clickElement(phonetypedrop);
		clickElement(mobiletype);
	}
	
	public void enteremail(String text) {
        sendText(email, text);
    }
	public void clickemail() {
		clickElement(emailtypedrop);
        clickElement(hometype);
	}
	public void clickSave() {
		clickElement(savebutton);
	}
}
