package pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunctions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class DeleteContact extends ReusableFunctions {
	
	public AndroidDriver driver;
	
	public DeleteContact(AndroidDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
        this.driver = driver;
    }
	
	@AndroidFindBy(xpath = "//android.widget.ListView/android.view.ViewGroup")
	public WebElement contact;
	
	@AndroidFindBy(id = "com.android.contacts:id/large_title")
	public WebElement contactTitle;
	
	@AndroidFindBy(accessibility = "More options")
	public WebElement more_optn;
	
	@AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.LinearLayout")
    public WebElement delete;
	
	@AndroidFindBy(id = "android:id/button1")
	public WebElement confirmDelete;
	
	public void clickContact() {
		clickElement(contact);
	}
	
	public void clickMoreOptions() {
		clickElement(more_optn);
	}
	
	public void clickDeleteButton() {
        clickElement(delete);
    }
	
	public void clickConfirmDeleteButton() {
        clickElement(confirmDelete);
    }
	
	public boolean checkContactTitle(String text) {
		return contactTitle.getText().equals(text);
	}
}
