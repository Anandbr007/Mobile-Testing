package utils;

import io.appium.java_client.android.AndroidDriver;

public class DriverUtils {
	
	public static AndroidDriver driver;

}
