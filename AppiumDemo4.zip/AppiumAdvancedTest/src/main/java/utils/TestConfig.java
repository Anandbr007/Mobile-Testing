package utils;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.DefaultValue;
import org.aeonbits.owner.Config.Key;

@Config.Sources("classpath:config/config.properties")
public interface TestConfig extends Config{
   
	@Key("APP")
    String getAPP();
	
	@Key("CONTACT_APP_PACKAGE")
    String getCONTACT_APP_PACKAGE();

	@Key("CONTACT_APP_ACTIVITY")
	String getCONTACT_APP_ACTIVITY();
	
	@Key("PORT")
	String getPORT();
	
	@Key("DEVICE_NAME")
    String getDEVICE_NAME();

	@Key("PLATFORM_NAME")
	String getPLATFORM_NAME();
	
	@Key("SENT_MESSAGE")
	String getSENT_MESSAGE();
	
	@Key("RECIPIENT")
	String getRECIPIENT();
	
	@Key("CHECK_RECIPIENT")
	String getCHECK_RECIPIENT();
	
	@Key("SCROLL_ELEMENT")
	String getSCROLL_ELEMENT();
	
	@Key("ERROR_MESSAGE")
	String getERROR_MESSAGE();
}
