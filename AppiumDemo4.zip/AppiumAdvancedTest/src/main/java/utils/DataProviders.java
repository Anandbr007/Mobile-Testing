package utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;

import base.ReusableFunctions;

public class DataProviders {

	@DataProvider(name="Jsondata")
	public Object[] getData() throws IOException {
		List<HashMap<String,String>> list  = ReusableFunctions.getJsonData("C:\\Users\\268852\\eclipse-workspace\\AppiumAdvancedTest\\src\\main\\resources\\Testdata\\Data.json");
		return list.toArray();
	}
}
