package testcases;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.aventstack.extentreports.util.Assert;

import pom.ContactsApp;
import pom.DeleteContact;

public class TestDeleteContact extends Hooks {

	public ContactsApp app;
	public DeleteContact dlt;
	
	@Test(priority= 0)
	public void testOpenContact() {
		app = new ContactsApp(driver);
		assertTrue(app.checkContacts());
	}
	
	@Test(priority=1)
	public void testClickContact() {
		dlt = new DeleteContact(app.passDriver());
		dlt.clickContact();
	}
	
	@Test(priority=2)
	public void testMoreOptions() {
		dlt.clickMoreOptions();
		dlt.clickDeleteButton();
		dlt.clickConfirmDeleteButton();
		assertTrue(dlt.checkContactTitle("Roshan M Shafeek"));
	}
}
