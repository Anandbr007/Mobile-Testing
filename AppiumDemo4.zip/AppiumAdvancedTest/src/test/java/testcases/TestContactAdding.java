package testcases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import pom.ContactsApp;
import pom.CreateContactPOM;
import utils.DataProviders;
import utils.ExtentReportsListener;

//@Listeners(ExtentReportsListener.class)
public class TestContactAdding extends Hooks {
	
	public CreateContactPOM app;
	
	@Test(priority= 0)
	public void testOpenContact() {
		app = new CreateContactPOM(driver);
		assertTrue(app.checkContacts());
		app.skip();
		app.clickAllow();
	}
	
	
	@Test(priority= 1)
	public void testClickPlus() {
		app = new CreateContactPOM(driver);
		app.clickCreate();
		assertTrue(app.checkaddbutton());
	}
	
	@Test(priority= 2)
	public void testClickAdd() {
		app = new CreateContactPOM(driver);
		app.clickAddbutton();
		assertEquals(app.canCreateAccount(),testconfig.getERROR_MESSAGE());
	}
	
	@Test(priority = 3)
	public void testClickCancel() {
		app = new CreateContactPOM(driver);
		app.goback();
//		app.goback();
		app.clickCancelbutton();
        assertTrue(app.checkContacts());	
	}
	
	
	@Test(priority = 4,dataProviderClass = DataProviders.class,dataProvider = "Jsondata")
	public void testenterData(HashMap<String,String> map) throws IOException {
		app = new CreateContactPOM(driver);
//		List<HashMap<String, String>> list = getJsonData(System.getProperty("user.dir")+"/src/main/resources/Testdata/Data.json");
		app.enterfirstname(map.get("First_name"));
		app.enterlastname(map.get("Last_name"));
		app.enterphone(map.get("Phone"));
		app.clickphone();
		app.enteremail(map.get("Email"));
		app.clickemail();
		app.clickSave();
	}
}
