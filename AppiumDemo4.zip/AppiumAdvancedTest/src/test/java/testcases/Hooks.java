package testcases;

import java.sql.Driver;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import base.ReusableFunctions;
import io.appium.java_client.android.AndroidDriver;
import utils.DriverUtils;

public class Hooks extends ReusableFunctions{


@BeforeTest
public void setup() {
	
	invokeDriver();
	
}

//@AfterTest
//public void teardown() {	
//	driver.quit();
//	stopServer();
//}
}
