package testCase;

import org.testng.annotations.Test;

import pom.Contactpom;
import utilities.ConfigAppium;

public class contactTest extends ConfigAppium {

	Contactpom contact;
	
    @Test
    public void contact() {
    	contact=new Contactpom(driver);
    	contact.popup();
    	contact.addContact();
       
    	
    }
	
}
