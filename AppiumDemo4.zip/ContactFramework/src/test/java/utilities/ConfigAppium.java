package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.Properties;

import org.testng.annotations.BeforeTest;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class ConfigAppium {

	public AndroidDriver driver;
	
	@BeforeTest
	public AndroidDriver setup() throws IOException {		
		Properties prop=new Properties();
		FileInputStream fs=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\Objectrepository\\data.properties");
		prop.load(fs);
		String ipaddress=prop.getProperty("ipaddress");
		String port=prop.getProperty("port");
		UiAutomator2Options options=new UiAutomator2Options();
		options.setDeviceName(prop.getProperty("AndroidDevicename"));
		options.setAppPackage("com.google.android.contacts");
		options.setAppActivity("com.android.contacts.activities.PeopleActivity");
		options.setPlatformName(prop.getProperty("os"));
		driver=new AndroidDriver(new URL("http://"+ipaddress+":"+port+"/"),options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		return driver;
		
	}
	
//	public void tearDown()
//	{
//		driver.quit();
//	}
}
