package org.example.pageobjects;

import java.util.List;

import org.example.utilities.ReusableFunctions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Batterypom {

	private AndroidDriver driver;
	ReusableFunctions rf;

	public Batterypom(AndroidDriver driver) {
		this.driver = driver;
		rf = new ReusableFunctions(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@FindBy(xpath = "//android.widget.TextView")
	List<WebElement> displayIcon;
	
	@AndroidFindBy(accessibility = "Battery")
	WebElement displayheading;
	
	@AndroidFindBy(id = "android:id/switch_widget")
	WebElement batteryPercent;
	
	@AndroidFindBy(accessibility = "Battery Saver")
	WebElement batterySaver;
	
	@FindBy(className = "android.widget.Switch")
	WebElement Batterysaverbtn;
	
	public void appOpening() {
		displayIcon.get(11).click();
		rf.takeADelay(2);
	}
	
	public String checkHeading() {
		return displayheading.getAttribute("content-desc");
	}
	
	public void batterypercent() {
		rf.takeADelay(2);
		batteryPercent.click();
	}
	
	public void saver() {
		displayIcon.get(6).click();
	}
	public String checkSaver() {
		return batterySaver.getAttribute("content-desc");
	}
	public void clickSaverBattery() {
		Batterysaverbtn.click();
	}
}
