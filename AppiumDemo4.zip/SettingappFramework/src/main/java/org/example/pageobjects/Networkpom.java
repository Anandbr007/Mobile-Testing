package org.example.pageobjects;

import java.util.List;

import org.example.utilities.ReusableFunctions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Networkpom {

	private AndroidDriver driver;
	ReusableFunctions rf;

	public Networkpom(AndroidDriver driver) {
		this.driver = driver;
		rf = new ReusableFunctions(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@FindBy(xpath = "//android.widget.TextView")
	List<WebElement> displayIcon;
	
	@AndroidFindBy(accessibility = "Network & internet")
	WebElement heading;
	
	@AndroidFindBy(accessibility = "Internet")
	WebElement internetcheck;
	
	@AndroidFindBy(id = "android:id/switch_widget")
	WebElement wifi;
	
	public void appOpening() {
		displayIcon.get(3).click();
		rf.takeADelay(2);
	}
	
	public String checkHEading() {
		return heading.getAttribute("content-desc");
	}
	
	public void clickInternet() {
		displayIcon.get(1).click();
		rf.takeADelay(2);
	}
	public String checkHeadingInternet() {
		return internetcheck.getAttribute("content-desc");
	}
	public void clickwifibtn() {
		wifi.click();
	}
}
