package org.example.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.example.testcases.JsonData;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class AndroidBaseTest  extends JsonData {
	public AndroidDriver driver;
	ReusableFunctions rf=new ReusableFunctions(driver);
	@BeforeTest
	public AndroidDriver ConfigureAppium() throws IOException, InterruptedException {
		 reports=ReusableFunctions.report("settingstest.html");
		// Load properties
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(
				System.getProperty("user.dir") + "\\src\\main\\java\\org\\example\\resources\\data.properties");
		prop.load(fis);
		// Configure Appium options and initialize driver
		String ipAddress = prop.getProperty("ipAddress");
		String port = prop.getProperty("port");

		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName(prop.getProperty("AndroidDeviceName"));
			options.setAppPackage(prop.getProperty("appPackage"));
			options.setAppActivity(prop.getProperty("appActivity"));
		

		driver = new AndroidDriver(new URL("http://" + ipAddress + ":" + port), options);

		return driver;
	}
	public ExtentSparkReporter htmlReporter;
	public ExtentReports reports;
	public ExtentTest test;
	@AfterMethod
	public void getTestResult(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " FAIL", ExtentColor.RED));
			ReusableFunctions.takeScreenShot(System.getProperty("user.dir") + "\\failedSreenshots");
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " PASS", ExtentColor.GREEN));
		} else if (result.getStatus() == ITestResult.SKIP) {
			test.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " SKIP", ExtentColor.YELLOW));
		}
	}
	@AfterTest()
	public void tearDown() {
		reports.flush();
	}

	
}
