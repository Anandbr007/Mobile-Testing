package org.example.stepdefinitions;


import static org.testng.Assert.assertEquals;

import org.example.pageobjects.Networkpom;
import org.example.utilities.AndroidBaseTest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Stepdefinitions extends AndroidBaseTest {
	public Networkpom network;
	
	@Given("open settings app")
	public void open_settings_app() {
		network=new Networkpom(driver);
		network.appOpening();
		assertEquals(network.checkHEading(), "Network & internet");
		
	}

	@When("click internet")
	public void click_internet() {
		network=new Networkpom(driver);
		network.clickInternet();
	}

	@Then("validate internet page")
	public void validate_internet_page() {
		network=new Networkpom(driver);
		assertEquals(network.checkHeadingInternet(), "Internet");

	}

	@When("click wifi button")
	public void click_wifi_button() {
		network=new Networkpom(driver);
		network.clickwifibtn();
	}

	@Then("validate wifi off")
	public void validate_wifi_off() {
		network=new Networkpom(driver);
	}
	

}
