package org.example.testcases;

import static org.testng.Assert.assertEquals;

import org.example.pageobjects.Batterypom;
import org.example.utilities.AndroidBaseTest;
import org.testng.annotations.Test;

public class Batterytest extends AndroidBaseTest {

	Batterypom battery ;
	
	@Test(priority = 1)
	public void start() {
		test = reports.createTest("Content Validation");
		battery = new Batterypom(driver);
		battery.appOpening();
	}
	@Test(priority = 2)
	public void checkDisplaytest() {
		test = reports.createTest("checkDisplaytest");
		battery = new Batterypom(driver);
		assertEquals(battery.checkHeading(), "Battery");
	}
	
	@Test(priority = 3)
	public void clickbatteryPercentagetest() {
		test = reports.createTest("clickbatteryPercentagetest");
		battery = new Batterypom(driver);
		battery.batterypercent();
	}
	@Test(priority = 4)
	public void clickBatterySavertest() {
		test = reports.createTest("clickBatterySavertest");
		battery = new Batterypom(driver);
		battery.saver();
	}
	@Test(priority = 5)
	public void checkSaverTest() {
		test = reports.createTest("checkSaverTest");
		battery = new Batterypom(driver);
		assertEquals(battery.checkSaver(), "Battery Saver");
	}
	
	@Test(priority = 6)
	public void clickBatterySaverbtntest() {
		test = reports.createTest("clickBatterySaverbtntest");
		battery = new Batterypom(driver);
		battery.clickSaverBattery();
	}
}
